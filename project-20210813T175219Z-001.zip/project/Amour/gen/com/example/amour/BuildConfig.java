/** Automatically generated file. DO NOT MODIFY */
package com.example.amour;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
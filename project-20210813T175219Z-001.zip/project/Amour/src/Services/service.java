package Services;

import com.example.amour.Category;

import android.app.IntentService;
import android.content.Intent;
import android.os.Handler;
import android.widget.Toast;

public class service extends IntentService {

	public service(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent arg0) {
		// TODO Auto-generated method stub
		final Handler handle= new Handler();
		new Thread()
		{
			public void run()
			{
				for(int i=1; i<=500;i++)
				{
					handle.post(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							Toast.makeText( null, "Notification", Toast.LENGTH_SHORT).show();
						}
					});
				}try {
					sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		
		}.start();
	}

}

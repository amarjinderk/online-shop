package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CashOnDelivery extends Activity {
	EditText e1,e2;
	Button b1,b2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.cash_on_delivery);
		e1=(EditText) findViewById(R.id.editText1);
		e2=(EditText) findViewById(R.id.editText2);
		b1=(Button) findViewById(R.id.button1);
		b2=(Button) findViewById(R.id.button2);
		
		final int rate=getIntent().getIntExtra("total",0);
		b1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				final String uname=pre.getString("uname", null);
				final String phone=e2.getText().toString();
				final String address=e1.getText().toString();
				 new Thread()
				  {
					 public void run()
					  {
						 HttpClient client=new DefaultHttpClient();
						 final HttpPost post=new HttpPost(Globals.webUrl+"Payment");
						 
						 try {
							//post.setEntity(new StringEntity(pre.getString("uname", null)));
							 	
								
											JSONObject jobj=new JSONObject();
											try {
												jobj.put("uname",uname);
												jobj.put("phone",phone );
												jobj.put("address", address);
												jobj.put("total", rate);
												post.setEntity(new StringEntity(jobj.toString()));
											} catch (JSONException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											} catch (UnsupportedEncodingException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
									
								client.execute(post);
								Intent myIntent = null;
								myIntent.putExtra("phone", phone.toString());
						} catch (UnsupportedEncodingException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (ClientProtocolException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
									  }
					 
				  }.start();
				  Intent myIntent = new Intent(getApplicationContext(),Category.class);
					startActivity(myIntent);
			}
		});
			b2.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent myIntent = new Intent(getApplicationContext(),Category.class);
                    startActivity(myIntent);
				}
			});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.cash_on_delivery, menu);
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        switch (item.getItemId()) {  
            case R.id.logout:  
            	SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				Editor ed=pre.edit();
                 ed.remove("uname");
                 ed.commit();
                 finish();
              Toast.makeText(getApplicationContext(),"Logout",Toast.LENGTH_LONG).show(); 
              Intent i=new Intent(CashOnDelivery.this,SignIn.class);
              startActivity(i);
            return true;     
           case R.id.About:  
              
                Intent i1=new Intent(CashOnDelivery.this,AboutUs.class);
	              startActivity(i1);
              return true;     
           case R.id.Cart:  
        	   Intent ij=new Intent(CashOnDelivery.this,ViewCart.class);
	              startActivity(ij);
             //   Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();  
             return true;    
          
           
              default:  
                return super.onOptionsItemSelected(item);  
        }  
    }  

}

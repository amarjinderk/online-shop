package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class Category extends Activity {
	GridView grid;
	 ArrayList web;
	  ArrayList imageId;
	  ArrayList catId;
	  ImageView grid_img;
	  final Context context = this;
	 // ProgressBar pb;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_category);
		  grid = (GridView)findViewById(R.id.gridView1);
		 // pb=(ProgressBar) findViewById(R.id.progressBar1);
		  grid_img=(ImageView) findViewById(R.id.grid_img);
		  web=new ArrayList();
		  catId=new ArrayList();
		  imageId=new ArrayList();
		// pb.setVisibility(View.VISIBLE);
		 
		  new Thread()
		  {
			  public void run()
			  {
				  
				  
				
				 
				  try {
					  HttpClient client=new DefaultHttpClient();
					  //HttpPost post=new HttpPost("http://192.168.42.97:8080/MaAmour/Catagory");
					 HttpPost post=new HttpPost(Globals.webUrl+"Catagory");
					 // HttpPost post=new HttpPost(Globals.imageURL+"Catagory");
					HttpResponse res=client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					System.out.println(data);
					runOnUiThread(new Runnable() 
					{
						public void run() {
							
							try {
								JSONArray jarr=new JSONArray(data);
								
								//CustomGrid adapter = new CustomGrid(getApplicationContext(),R.layout.activity_category, web, imageId);
						
								//ArrayAdapter adp=new ArrayAdapter(getApplicationContext(), android.R.layout.simple_expandable_list_item_1);
								System.out.println(jarr);
								for(int i=0;i<jarr.length();i++)
								{
									JSONObject obj=jarr.getJSONObject(i);
									// web.add(obj.getString("catid"));
									//SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
									//obj.put("uname", pre.getString("uname", null));
									web.add(obj.getString("catname"));
									catId.add(obj.getString("catid"));
									imageId.add(obj.get("catp"));
									//Toast.makeText(Category.this, "Going to Subcate" +obj.put("uname", pre.getString("uname", null)) , Toast.LENGTH_SHORT).show();
									
								}
								
								CustomGrid adapter = new CustomGrid(Category.this,R.layout.grid_view,web,imageId);
	
								grid.setAdapter(adapter);
								//pb.setVisibility(View.GONE);
								
								grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					                @Override
					        public void onItemClick(AdapterView<?> parent, View view,
					                                        int position, long id) 
					             {
					                	
					                   //Toast.makeText(Category.this, "You Clicked at " +web , Toast.LENGTH_SHORT).show();
					                	Intent myIntent = new Intent(getApplicationContext(),SubCategory.class);
					                	myIntent.putExtra("catid", catId.get(position).toString());
					                    startActivity(myIntent);
					                    Toast.makeText(Category.this, "Going to Subcategory", Toast.LENGTH_SHORT).show();
					                
					                	
					             }
					                
					            });
								//grid.setAdapter(adp);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
					});
					
					
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  }
		  }.start();
		  
		 
		
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_category, menu);
				return true;
	}
	
 @Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
		 alertDialogBuilder.setTitle("Are You Sure you want to Exit ?");
		 alertDialogBuilder.setMessage("Click yes to exit!")
		 .setCancelable(false).setPositiveButton("Yes",new DialogInterface.OnClickListener()
		 {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Category.this.finish();
			}
			 
		 }).setNegativeButton("No",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,
						int id) {
					// if this button is clicked, just close
					// the dialog box and do nothing
					dialog.cancel();
				}
			});

			// create alert dialog
			AlertDialog alertDialog = alertDialogBuilder.create();
			
			// show it
			alertDialog.show();
			
			}
			
			
	
	
						
	


	@Override  
	    public boolean onOptionsItemSelected(MenuItem item) {  
	        switch (item.getItemId()) {  
	            case R.id.logout:  
	            	SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
					Editor ed=pre.edit();
	                 ed.remove("uname");
	                 ed.commit();
	                 finish();
	              Toast.makeText(getApplicationContext(),"Logout",Toast.LENGTH_LONG).show(); 
	              Intent i=new Intent(Category.this,SignIn.class);
	              startActivity(i);
	            return true;     
	           case R.id.About:  
	              
	                Intent i1=new Intent(Category.this,AboutUs.class);
		              startActivity(i1);
	              return true;     
	           case R.id.Cart:  
	        	   Intent ij=new Intent(Category.this,ViewCart.class);
		              startActivity(ij);
	             //   Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();  
	             return true;    
	          
	           case R.id.Order:  
	        	   Intent ki=new Intent(Category.this,OrderDetails.class);
		              startActivity(ki);
	             //   Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();  
	             return true;
	              default:  
	                return super.onOptionsItemSelected(item);  
	        }  
	    }  

}

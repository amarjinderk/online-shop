package com.example.amour;

import java.net.URL;
import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class CustomGrid extends ArrayAdapter {
	Context mContext=null;
    ArrayList web;
    Handler handle=new Handler();
    ArrayList imageid;
      public CustomGrid(Context c,int resource,ArrayList web,ArrayList imageid ) {
          super(c,resource,web);
    	  mContext = c;
          this.imageid = imageid;
          this.web = web;
      }
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		  View grid;
	      LayoutInflater inflater = (LayoutInflater) mContext
	        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	      
	      /*convertView=inflater.inflate(R.layout.grid_view, null);
	      TextView t1=(TextView) convertView.findViewById(R.id.grid_txt);
	      t1.setText(web.get(position).toString());
	      return convertView;*/
	         if (convertView == null) {
	            grid = new View(mContext);
	        grid = inflater.inflate(R.layout.grid_view, null);
	            TextView textView = (TextView) grid.findViewById(R.id.grid_txt);
	            final ImageView imageView = (ImageView)grid.findViewById(R.id.grid_img);
	            textView.setText(web.get(position).toString());
	            final ProgressBar pbar=(ProgressBar) grid.findViewById(R.id.gridprogress);
	            new Thread()
	            {
	            	public void run()
	            	{
	            		try
	            		{
	            			final Bitmap bmp=BitmapFactory.decodeStream(new URL(Globals.imageURL+imageid.get(position)).openStream());
	            			handle.post(new Runnable() {
	            				public void run() {
	            					if(bmp!=null)
	            					{
	            						imageView.setImageBitmap(bmp);
	            						imageView.setVisibility(View.VISIBLE);
	            						pbar.setVisibility(View.GONE);
	            					}
	            					else
	            					{
	            						Toast.makeText(mContext, "Not found", Toast.LENGTH_SHORT).show();
	            					}
	            				}
	            			});
	            		}
	            		catch (Exception e) {
							// TODO: handle exception
	            			e.printStackTrace();
						}
	            	}
	            }.start();
	            //imageView.setImageURI(Uri.parse(Globals.imageURL+Imageid.get(position)));
	            //imageView.setImageResource(R.drawable.ic_launcher);
	          } else {
	            grid = (View) convertView;
	          }
	      return grid;
	}

}

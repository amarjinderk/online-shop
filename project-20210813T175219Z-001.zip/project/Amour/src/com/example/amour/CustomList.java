package com.example.amour;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomList extends ArrayAdapter<String>  {
	Context mContext=null;
    ArrayList pn;
    Handler handle=new Handler();
    ArrayList Imageid;
	public CustomList(Context context,int resource,ArrayList pn,ArrayList Imageid ) {
		super(context, resource,pn);
		// mContext = context;
		this.mContext=context;
         this.Imageid = Imageid;
         this.pn = pn;
		// TODO Auto-generated constructor stub
	}
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		View list = null;
	      LayoutInflater inflater = (LayoutInflater) mContext       //.getLayoutInflater();
	    		  .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	      if (convertView == null) {
	            list = new View(mContext);
	        list = inflater.inflate(R.layout.list_view, null,true);
	            TextView textView = (TextView) list.findViewById(R.id.text_list);
	            final ImageView imageView = (ImageView)list.findViewById(R.id.list_img);
	            textView.setText(pn.get(position).toString());
		//return super.getView(position, convertView, parent);
	            new Thread()
	            {
	            	public void run()
	            	{
	            		final Bitmap bmp;
						try {
							bmp = BitmapFactory.decodeStream(new URL(Globals.imageURL+Imageid.get(position)).openStream());
							handle.post(new Runnable() {

								@Override
								public void run() {
									// TODO Auto-generated method stub
									if(bmp!=null)
	            					{
	            						imageView.setImageBitmap(bmp);
	            					}
	            					else
	            					{
	            						Toast.makeText(mContext, "Not found", Toast.LENGTH_SHORT).show();
	            					}
								}
		            			
		            		});
							
						} catch (MalformedURLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	            		
	            	}
	            	
	            }.start();
	}
	      else
	      {
	    	  list= (View) convertView;
	      }
		return list;
	}


}

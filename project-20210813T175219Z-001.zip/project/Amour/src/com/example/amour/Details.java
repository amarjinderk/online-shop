package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Details extends Activity {
	TextView t1;
	TextView t2,t3;
	Button b1,b2;
	ImageView im;
	ArrayList productname;
	ArrayList productid;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_details);
		t1 = (TextView)findViewById(R.id.productn);
		t2=(TextView)findViewById(R.id.rate);
		t3=(TextView)findViewById(R.id.des);
		b1=(Button) findViewById(R.id.button1);
		b2=(Button) findViewById(R.id.button2);
		im=(ImageView) findViewById(R.id.img);
		productname=new ArrayList();
		productid=new ArrayList();
		final String productid=getIntent().getStringExtra("productid").toString();
		final String productname=getIntent().getStringExtra("productname").toString();
		final String rate=getIntent().getStringExtra("rate").toString();
		final String des=getIntent().getStringExtra("des").toString();
		final String pic=getIntent().getStringExtra("pic").toString();
		 new Thread()
		  {
			  public void run()
			  {
				  try {
					  HttpClient client=new DefaultHttpClient();
					  HttpPost post=new HttpPost(Globals.webUrl+"Details");
					post.setEntity(new StringEntity(productid));
					//SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
					//post.setEntity(new StringEntity(pre.getString("uname", null)));
					
					HttpResponse res=client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					System.out.println("Data "+data);
					runOnUiThread(new Runnable() {
							public void run() {

								
							try {
								JSONArray jarr=new JSONArray(data);
								System.out.println(jarr);
								
								for(int i=0;i<jarr.length();i++)
								{
									JSONObject obj=jarr.getJSONObject(i);
									
									//web.add(obj.getString("productname"));
									//t1.setText(productid);
									//t2.setText((CharSequence) web);
									new Thread()
									{
										public void run()
										{
											try {
												final Bitmap bm=BitmapFactory.decodeStream(new URL(Globals.imageURL+pic).openStream());
												runOnUiThread(new Runnable() {
													public void run() {
														im.setImageBitmap(bm);
													}
												});
											} catch (MalformedURLException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											} catch (IOException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
										}
									}.start();
									t1.setText(productname);
									t2.setText(rate);
									t3.setText(des);
									
							
								}
								b1.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										new Thread()
										{
											public void run()
											{ 
										try {
											
											HttpClient client=new DefaultHttpClient();
											HttpPost post=new HttpPost(Globals.webUrl+"AddToCart");
											
											//JSONArray jarr=new JSONArray(data);
											//System.out.println(jarr);
											//for(int i=0;i<jarr.length();i++)
										//	{
											SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
											JSONObject obj=new JSONObject();
											obj.put("productid", productid);
											obj.put("uname", pre.getString("uname", null));
											post.setEntity(new StringEntity(obj.toString()));
									
										//	}
											HttpResponse res=client.execute(post);
											
}
										catch (UnsupportedEncodingException e1) {
											// TODO Auto-generated catch block
											e1.printStackTrace();
										}
										 catch (ClientProtocolException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										} catch (IOException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										} catch (JSONException e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
											}
										}.start();
										
										try {
											 Toast.makeText(Details.this, "You product is added into cart " , Toast.LENGTH_SHORT).show();
											Intent myIntent = new Intent(getApplicationContext(),Category.class);
											myIntent.putExtra("rate", rate);
										startActivity(myIntent);
											//JSONObject obj=new JSONObject();
											//obj.put("productid", productid);
											
										
											
										
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
										
									}
								});
								b2.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										
										Intent myIntent = new Intent(getApplicationContext(),Category.class);
										startActivity(myIntent);
									}
								});
								
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					});
				  } catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  }
			  }.start();
								
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_details, menu);
		
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        switch (item.getItemId()) {  
            case R.id.logout:  
            	SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				Editor ed=pre.edit();
                 ed.remove("uname");
                 ed.commit();
                 finish();
              Toast.makeText(getApplicationContext(),"Logout",Toast.LENGTH_LONG).show(); 
              Intent i=new Intent(Details.this,SignIn.class);
              startActivity(i);
            return true;     
           case R.id.About:  
              
                Intent i1=new Intent(Details.this,AboutUs.class);
	              startActivity(i1);
              return true;     
           case R.id.Cart:  
        	   Intent ij=new Intent(Details.this,ViewCart.class);
	              startActivity(ij);
             //   Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();  
             return true;    
          
           case R.id.Order:  
        	   Intent ki=new Intent(Details.this,OrderDetails.class);
	              startActivity(ki);
             //   Toast.makeText(getApplicationContext(),"Item 3 Selected",Toast.LENGTH_LONG).show();  
             return true;
              default:  
                return super.onOptionsItemSelected(item);  
        }  
    }  

}

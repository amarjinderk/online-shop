package com.example.amour;

public class Globals {
	//static String webUrl="http://192.168.42.97:8080/MaAmour/";
	//static String webUrl="http://192.168.247.59:8080/MaAmour/";
	//static String imageURL="http://192.168.247.59/products/";
	static String webUrl="http://192.168.43.214:8080/MaAmour/";
	//static String imageURL="http://192.168.42.97/products/";
	static String imageURL="http://192.168.43.214/products/";
	//static String imageURL="http://192.168.1.7/products/";
	//static String webUrl="http://192.168.1.7:8080/MaAmour/";
	
}

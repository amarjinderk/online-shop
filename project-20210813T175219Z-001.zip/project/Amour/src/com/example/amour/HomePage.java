package com.example.amour;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class HomePage extends Activity {
	/*GridView grid;
	String[] web = {"hello"};
	int[] imageId = {
		      R.drawable.back};
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home_page);
		CustomGrid adapter = new CustomGrid(HomePage.this, web, imageId);
		 grid=(GridView)findViewById(R.id.gridView1);
		 grid.setAdapter(adapter);
		 grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Toast.makeText(HomePage.this, "You Clicked at " +web[+ arg2], Toast.LENGTH_SHORT).show();
			}
		});
		 /*grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view,
                                     int position, long id) {
                 Toast.makeText(HomePage.this, "You Clicked at " +web[+ position], Toast.LENGTH_SHORT).show();
             }
         });
	}*/

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.home_page, menu);
		return true;
	}

}

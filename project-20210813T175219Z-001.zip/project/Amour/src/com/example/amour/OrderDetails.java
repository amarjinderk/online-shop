package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class OrderDetails extends Activity {
TextView t5,t6,t7,t8;
ArrayList Phone;
ArrayList Address,Total,Orderno;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.order_details);
		
		t5=(TextView) findViewById(R.id.on);
		t6=(TextView) findViewById(R.id.add);
		t7=(TextView) findViewById(R.id.total);
		t8=(TextView) findViewById(R.id.phn);
		Address=new ArrayList();
		Total=new ArrayList();
		Phone=new ArrayList();
		Orderno=new ArrayList();
		
		//final String total=getIntent().getStringExtra("total").toString();
		//final String address=getIntent().getStringExtra("address").toString();
		//final String orderno=getIntent().getStringExtra("orderno").toString();
		//final String phn=getIntent().getStringExtra("phone").toString();
		 new Thread()
		  {
			 public void run()
			  {
				 HttpClient client=new DefaultHttpClient();
				  HttpPost post=new HttpPost(Globals.webUrl+"Cash");
				  SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				  try {
					post.setEntity(new StringEntity(pre.getString("uname", null)));
					//final String address=t7.setText(address).toString();
					HttpResponse res;
					res = client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					System.out.println(data);
					runOnUiThread(new Runnable() 
					{

						@Override
						public void run() {
							// TODO Auto-generated method stub
							JSONArray jarr;
							try {
								jarr = new JSONArray(data);
								System.out.println(jarr);
								boolean d;
								for(int i=0;i<jarr.length();i++)
								{
									//SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
									JSONObject obj=jarr.getJSONObject(i);
									t6.setText(obj.getString("address"));
									t7.setText(obj.getString("total"));
									t8.setText(obj.getString("phone"));
									t5.setText(obj.getString("orderno"));
									//obj.put("uname", pre.getString("uname", null));
									//t5.setText("orderno");
									//t6.setText(address);
									//
									//t8.setText("total");
								//	Orderno.add(obj.getString("Orderno"));
									//Phone.add(obj.getString("Phone"));
									//Address.add(obj.get("address"));
									//Total.add(obj.get("Total"));
									
									
							}
								
								
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
						
						
					});

				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				  
								  }
				
			 
		  }.start();
		//  t7.setText("phone");
		//  t5.setText(orderno);
		//t6.setText(address);
		 // t7.setText(phn);
		  //t8.setText(total);
		  
			  
		  
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.order_details, menu);
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        switch (item.getItemId()) {  
            case R.id.logout:  
            	SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
				Editor ed=pre.edit();
                 ed.remove("uname");
                 ed.commit();
                 finish();
              Toast.makeText(getApplicationContext(),"Logout",Toast.LENGTH_LONG).show(); 
              Intent i=new Intent(OrderDetails.this,SignIn.class);
              startActivity(i);
            return true;     
           case R.id.About:  
              
                Intent i1=new Intent(OrderDetails.this,AboutUs.class);
	              startActivity(i1);
              return true;     
               default:  
                return super.onOptionsItemSelected(item);  
        }  
    }  
	

	
	

}

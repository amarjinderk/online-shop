
package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class Products2 extends Activity {
	GridView grid;
	  ArrayList imageId;
	  
	  
	  
	  ArrayList productid;
	  ArrayList productname;
	  ArrayList rate;
	  ArrayList des;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.products2);
		grid=(GridView)findViewById(R.id.gridView1);
		imageId=new ArrayList();
		 productid=new ArrayList();
		productname= new ArrayList();
		rate= new ArrayList();
		 des= new ArrayList();
		 final String subcatid=getIntent().getStringExtra("subcatid").toString();
		 new Thread()
		  {
			  public void run()
			  {
				  try {
					  HttpClient client=new DefaultHttpClient();
					  HttpPost post=new HttpPost(Globals.webUrl+"Products");
					  post.setEntity(new StringEntity(subcatid));
					HttpResponse res=client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					System.out.println("Data "+data);
					runOnUiThread(new Runnable() {
							public void run() {
							
							try {
								JSONArray jarr=new JSONArray(data);
								
								//CustomGrid adapter = new CustomGrid(getApplicationContext(),R.layout.activity_category, web, imageId);
						
								//ArrayAdapter adp=new ArrayAdapter(getApplicationContext(), android.R.layout.simple_expandable_list_item_1);
								System.out.println(jarr);
								for(int i=0;i<jarr.length();i++)
								{
									JSONObject obj=jarr.getJSONObject(i);
									
									  imageId.add(obj.get("pic"));
									productname.add(obj.getString("Productname"));
									productid.add(obj.getString("productid"));
									
									
									rate.add(obj.getString("rate"));
									des.add(obj.getString("des"));
								
								}
								CustomGrid adapter = new CustomGrid(Products2.this,R.layout.grid_view,productname,imageId);
								grid.setAdapter(adapter);
								grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					                @Override
					                public void onItemClick(AdapterView<?> parent, View view,
					                                        int position, long id) 
					                {
					                   
					                   Intent myIntent = new Intent(getApplicationContext(),Details2.class);
					                	myIntent.putExtra("productid", productid.get(position).toString());
					                	myIntent.putExtra("productname", productname.get(position).toString());
					                	myIntent.putExtra("rate", rate.get(position).toString());
					                	myIntent.putExtra("des", des.get(position).toString());
					                	myIntent.putExtra("pic", imageId.get(position).toString());
					                    startActivity(myIntent);
					                    Toast.makeText(Products2.this, "You Clicked " , Toast.LENGTH_SHORT).show();
					                 
					                	
					                }
					            });
								//grid.setAdapter(adp);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					});
				  } catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  }
			  }.start();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.products2, menu);
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) { 
		  switch (item.getItemId()) {
		  case R.id.About:

              Intent i1=new Intent(Products2.this,AboutUs.class);
	              startActivity(i1);
            return true;  
		  
    default:  
        return super.onOptionsItemSelected(item); 
		  }
	}


}

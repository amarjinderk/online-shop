package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

public class SignIn extends Activity {
	
	EditText un;
	EditText pas;
	Button login;
	AlertDialog dialog;
	//private ProgressDialog mProgress;
	ProgressBar pb;
	//ArrayList eid;
	//ArrayList pass;
	final Context context = this;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.log_in);
		 Toast.makeText(SignIn.this, "Authentication required", Toast.LENGTH_SHORT).show();
		// Toast.makeText(SignIn.this, "Authentication required" +g, Toast.LENGTH_SHORT).show();
		 
		 
		 un=(EditText)findViewById(R.id.unm);
		 pas=(EditText)findViewById(R.id.pwd);
		login=(Button)findViewById(R.id.login);
		 pb =  (ProgressBar) findViewById(R.id.pb);
		 dialog=new AlertDialog.Builder(this).create();
	        dialog.setTitle(" MSG ");
		un.addTextChangedListener(new TextWatcher() {
			final String email=un.getText().toString();
			String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
					+ "[A-Za-z0-9-]+(\\.[A-Za-stringz0-9]+)*(\\.[A-Za-z]{2,})$";
			
			
			
			

			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				if(un.getText().toString().equals("") || un.getText().toString().equals( EMAIL_PATTERN)){
					un.setError("Please enter username or valid email");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				if(un.getText().toString().equals("")|| un.getText().toString().equals(" EMAIL_PATTERN")){
					un.setError("Please enter username");
				}
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				if(un.getText().toString().equals("")|| un.getText().toString().equals( "EMAIL_PATTERN")){
					un.setError("Please enter username");
				}
			}
		});
		
pas.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
				// TODO Auto-generated method stub
				if(pas.getText().toString().equals("")|| pas.length() <=3){
					pas.setError("Please enter password & password must contain 4 digits ");
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
					int arg3) {
				// TODO Auto-generated method stub
				if(pas.getText().toString().equals("") && pas.length() <=3){
					pas.setError("Please enter password & password must contain 4 digits ");
				}
			}
			
			@Override
			public void afterTextChanged(Editable arg0) {
				// TODO Auto-generated method stub
				if(pas.getText().toString().equals("")){
					pas.setError("Please enter password");
				}
			}
		});

		pb.setVisibility(View.GONE);
		/*mProgress = new ProgressDialog(this);
		mProgress.setTitle("Processing...");
		mProgress.setMessage("Please wait...");
		mProgress.setCancelable(false);
		mProgress.setIndeterminate(true);*/
		login.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				pb.setVisibility(View.VISIBLE);
				
				new Thread()
				{
					public void run()
					{
						try {
							HttpClient client=new DefaultHttpClient();
							// HttpPost post=new HttpPost("http://192.168.42.97:8080/MaAmour/SubCategory");
							HttpPost post=new HttpPost(Globals.webUrl+"SignIn");
							final JSONObject obj=new JSONObject();
							obj.put("un", un.getText().toString());	
							obj.put("pas", pas.getText().toString());
							post.setEntity(new StringEntity(obj.toString()));
							HttpResponse res=client.execute(post);
							BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
							final String data=bf.readLine();
							System.out.println("Data "+data);
							// mProgress.show();
					            // Retrieve the text entered from the EditText
					            //usernametxt = username.getText().toString();
					            //passwordtxt = password.getText().toString();
							//pb.setVisibility(View.Visible);
							// Thread.sleep(2000);
							runOnUiThread(new Runnable() {
								public void run() {
									
												// TODO Auto-generated method stub
												
												//if(un==null)
												//{
												//show("Please Enter Correct email address.");
												//	}
												//	else if(pas==null||pas.length()<6)
												//	{
												//		show("Please Enter Correct Password.");
												//	}
												if(data.equals("yes"))
												{	
													//mProgress.dismiss(); 
													SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
													Editor ed=pre.edit();
													//ed logged=("uname", un.getText().toString());
													ed.putString("uname", un.getText().toString());
													ed.commit();
													Intent myIntent = new Intent(getApplicationContext(),Category.class);
													
								                    startActivity(myIntent);
								                    finish();
								                    
													Toast.makeText(SignIn.this, "successfully logged in", Toast.LENGTH_LONG).show();
												}
												else
												{
													//pb.dismiss(); 
													
													Toast.makeText(SignIn.this, "Logged in fail", Toast.LENGTH_LONG).show();
													pb.setVisibility(View.GONE);
												}
												
									
								}
							});
						} catch (ClientProtocolException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (JSONException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}.start();
			
		            }
		});
			  
		
	
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_sign_in, menu);
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) {  
        switch (item.getItemId()) {  
            case R.id.Back: 
            	Intent i=new Intent(SignIn.this,FirstScreen.class);
	             startActivity(i);

            return true;     
              default:  
                return super.onOptionsItemSelected(item);  
        }  
    } 
	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		//super.onBackPressed();
		 AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(context);
		 alertDialogBuilder.setTitle("Are You Sure you want to Exit ?");
		 alertDialogBuilder.setMessage("Click yes to exit!")
		 .setCancelable(false).setPositiveButton("Yes",new DialogInterface.OnClickListener()
		 {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				SignIn.this.finish();
			}
			 
		 }).setNegativeButton("No",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,
						int id) {
					// if this button is clicked, just close
					// the dialog box and do nothing
					dialog.cancel();
				}
			});

			// create alert dialog
			AlertDialog alertDialog = alertDialogBuilder.create();
			
			// show it
			alertDialog.show();
			
			}

	

}

package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class SubCat2 extends Activity {
	GridView grid1;
	 ArrayList web;
	ArrayList subcatId;
	  ArrayList imageId;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub_cat2);
		grid1=(GridView)findViewById(R.id.gridView1);
		 web=new ArrayList();
		 imageId=new ArrayList();
		 subcatId= new ArrayList();
		 final String catid=getIntent().getStringExtra("catid").toString(); 
		 new Thread()
		  {
			  public void run()
			  {
				  try {
					  HttpClient client=new DefaultHttpClient();
					 // HttpPost post=new HttpPost("http://192.168.42.97:8080/MaAmour/SubCategory");
					  HttpPost post=new HttpPost(Globals.webUrl+"SubCategory");
					  
					  post.setEntity(new StringEntity(catid));
					HttpResponse res=client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					System.out.println("Data "+data);
					runOnUiThread(new Runnable() {
							public void run() {
							
							try {
								JSONArray jarr=new JSONArray(data);
								
								//CustomGrid adapter = new CustomGrid(getApplicationContext(),R.layout.activity_category, web, imageId);
						
								//ArrayAdapter adp=new ArrayAdapter(getApplicationContext(), android.R.layout.simple_expandable_list_item_1);
								System.out.println(jarr);
								for(int i=0;i<jarr.length();i++)
								{
									JSONObject obj=jarr.getJSONObject(i);
									
									  
									web.add(obj.getString("Subcatname"));
									subcatId.add(obj.getString("subcatid"));
									imageId.add(obj.get("subcatp"));
								}
								CustomGrid adapter = new CustomGrid(SubCat2.this,R.layout.grid_view,web,imageId);
								grid1.setAdapter(adapter);
								grid1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					                @Override
					                public void onItemClick(AdapterView<?> parent, View view,
					                                        int position, long id) 
					                {
					                	
					                	
					                	
					                	Intent myIntent = new Intent(getApplicationContext(),Products2.class);
					                	myIntent.putExtra("subcatid", subcatId.get(position).toString());
					                    startActivity(myIntent);
					                	// myIntent =getIntent();
	                			        // myIntent.getStringArrayExtra("catid");
	                			         
					                	
					                Toast.makeText(SubCat2.this, "Going to Products", Toast.LENGTH_SHORT).show();
					                	
					                   //Toast.makeText(Category.this, "You Clicked at " +web , Toast.LENGTH_SHORT).show();
					                	
					                }
					            });
								//grid.setAdapter(adp);
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					});
				  } catch (ClientProtocolException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				  }
			  }.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.sub_cat2, menu);
		return true;
	}
	@Override  
    public boolean onOptionsItemSelected(MenuItem item) { 
		  switch (item.getItemId()) {
		  case R.id.About:

              Intent i1=new Intent(SubCat2.this,AboutUs.class);
	              startActivity(i1);
            return true;  
		  
    default:  
        return super.onOptionsItemSelected(item); 
		  }
	}


}

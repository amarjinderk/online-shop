package com.example.amour;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.Bundle;
import android.preference.PreferenceManager;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewCart extends Activity {
	
	ListView list;
	ArrayList pn;
	ArrayList imageid,pid,rate;
	CustomList adapter;
	TextView t1;
	int total;
	Button b1;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_cart);
		 pn=new ArrayList();
		  pid=new ArrayList();
		  imageid=new ArrayList();
		  
		 // setListAdapter(adapter);
		 //final String rate=getIntent().getStringExtra("rate").toString();
		 list = (ListView)findViewById(R.id.listView1);
		t1 =(TextView) findViewById(R.id.tt);
		b1 =(Button) findViewById(R.id.checkout);
		 new Thread()
		  {
			  public void run()
			  {
				  
				  
				 
				try {
					 HttpClient client=new DefaultHttpClient();
					  //HttpPost post=new HttpPost("http://192.168.42.97:8080/MaAmour/Catagory");
					 final HttpPost post=new HttpPost(Globals.webUrl+"ViewCart");
					 SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
					 //JSONObject obj=new JSONObject();
						//obj.put("username", pre.getString("uname", null)); 
						post.setEntity(new StringEntity(pre.getString("uname", null)));
					 // HttpPost post=new HttpPost(Globals.imageURL+"Catagory");
					HttpResponse res;
					res = client.execute(post);
					BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
					final String data=bf.readLine();
					//SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
										
					System.out.println(data);
					runOnUiThread(new Runnable() 
					{
						public void run() {
							
							try {
								JSONArray jarr=new JSONArray(data);
								
								
								System.out.println(jarr);
								for(int i=0;i<jarr.length();i++)
								{
									//SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
									JSONObject obj=jarr.getJSONObject(i);
									//obj.put("uname", pre.getString("uname", null));
									pn.add(obj.getString("ProductName"));
									pid.add(obj.getString("ProductId"));
									imageid.add(obj.get("Picture"));
									
									total=total+Integer.parseInt(obj.getString("rate"));
									

									
									
								}
								t1.setText("Total : "+total);
								adapter = new CustomList(ViewCart.this,R.layout.list_view,pn,imageid);
								list.setAdapter(adapter);
						
								
								
								b1.setOnClickListener(new OnClickListener() {
									
									@Override
									public void onClick(View arg0) {
										// TODO Auto-generated method stub
										Intent myIntent = new Intent(getApplicationContext(),Paymenttype.class);
										myIntent.putExtra("total", total);
										startActivity(myIntent);
									}
								});
								
							list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
					                @Override
					        public void onItemClick(AdapterView<?> parent, View view,
					                                        int position, long id) 
					             {
					                
					                  Toast.makeText(ViewCart.this, "You Clicked at " +pid.get(position).toString(), Toast.LENGTH_SHORT).show();
					                	Intent myIntent = new Intent(getApplicationContext(),CashOnDelivery.class);
					                	myIntent.putExtra("total", total);
					                	startActivity(myIntent);
					                    
					                registerForContextMenu(list);
					                
					             }
					                
					                
					            });
							
							
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
						
					});
				} 
				catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			  }
		  }.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.view_cart, menu);
		return true;
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// TODO Auto-generated method stub
	
		super.onCreateContextMenu(menu, v, menuInfo);
		menu.add("Delete");
		menu.add("Details");
		
	}
	

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		 super.onContextItemSelected(item);
		 if(item.getTitle()=="Delete")
		 {		AdapterContextMenuInfo in=(AdapterContextMenuInfo) item.getMenuInfo();
		 
		 		final int pos= in.position;
		 		
			 new Thread()
			  {
				 public void run() {
					 
						
						 //Toast.makeText(ViewCart.this, "You Clicked at Delete" +pos, Toast.LENGTH_SHORT).show();
						 HttpClient client=new DefaultHttpClient();
						 final HttpPost post=new HttpPost(Globals.webUrl+"Delete");
						// SharedPreferences pre=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
						 try {
							 post.setEntity(new StringEntity(pid.get(pos).toString()));
							
							 HttpResponse res;
							res = client.execute(post);
					
							BufferedReader bf=new BufferedReader(new InputStreamReader(res.getEntity().getContent()));
							final String data=bf.readLine();
							System.out.println(data);
							
							
							
							runOnUiThread(new Runnable() 
							{
								public void run() {
									Toast.makeText(ViewCart.this, "You Clicked at " +pos, Toast.LENGTH_SHORT).show();

									adapter.remove(adapter.getItem(pos));
									adapter.notifyDataSetChanged();
								}
							});
							//adapter.remove(adapter.getItem(pos));
							
						//	notifyDataSetChanged();

					        //Toast.makeText(this, "You have chosen the " + getResources().getString(R.string.delete) + 
					               // " context menu option for " + names[(int)info.id],
					                //Toast.LENGTH_SHORT).show();

					       							
						 } catch (UnsupportedEncodingException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (ClientProtocolException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
								

						 }
					}.start();
			 
			
		 
					
					 
	}
		 
		 return true;
		


	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		 case R.id.orderdetails:  
             
             Intent i1=new Intent(ViewCart.this,OrderDetails.class);
            // i1 = new Intent(getApplicationContext(),OrderDetails.class);
	              startActivity(i1);
           return true; 
		}
		return super.onOptionsItemSelected(item);
	}

}

	




import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import connection.connect;

/**
 * Servlet implementation class AddToCart
 */
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCart() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn = null;
		
		conn=connect.getConnection();
		BufferedReader bf=new BufferedReader(new InputStreamReader(request.getInputStream()));
		String productid=bf.readLine();
	
		Statement st;
		try {
			st = conn.createStatement();
			String cat="Select * from dbo.AddToCart where ProductId='"+productid+"'";
			ResultSet rs =st.executeQuery(cat);
			JSONArray jarr=new JSONArray();
			while(rs.next())
			{	JSONObject jobj=new JSONObject();
				jobj.put("SrNo", rs.getString("SrNo"));
				jobj.put("UserId", rs.getString("UserId"));
				jobj.put("ProductId", rs.getString("ProductId"));
				jarr.put(jobj);
				
			}
			PrintWriter pr=response.getWriter();
			System.out.println(jarr);
			pr.print(jarr);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}





import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import connection.connect;

/**
 * Servlet implementation class Catagory
 */
public class Catagory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Catagory() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		Connection conn = null;
		
			conn=connect.getConnection();
			
		
		
		
		
		Statement st;
		
		try {
			st = conn.createStatement();
			String cat="Select * from dbo.category";
			ResultSet rs =st.executeQuery(cat);
			JSONArray jarr=new JSONArray();
			while(rs.next())
			{	JSONObject jobj=new JSONObject();
				jobj.put("catname", rs.getString("CatName"));
				jobj.put("catid", rs.getString("CatId"));
				jobj.put("catp", rs.getString("CatPic"));
				jarr.put(jobj);
				
			}
			PrintWriter pr=response.getWriter();
			System.out.println(jarr);
			pr.print(jarr);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

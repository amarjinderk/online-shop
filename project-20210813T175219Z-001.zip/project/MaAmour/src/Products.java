

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import connection.connect;

/**
 * Servlet implementation class Products
 */
public class Products extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Products() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
Connection conn = null;
		
		conn=connect.getConnection();
		
	
	
		BufferedReader bf=new BufferedReader(new InputStreamReader(request.getInputStream()));
		String subcatid=bf.readLine();
		System.out.println(subcatid);
	
	Statement st;
	
	try {
		st = conn.createStatement();
		String cat="Select * from dbo.products where SubCatId='"+subcatid+"'";
		ResultSet rs =st.executeQuery(cat);
		JSONArray jarr=new JSONArray();
		while(rs.next())
		{
			JSONObject jobj=new JSONObject();
			jobj.put("Productname", rs.getString("ProductName"));
			jobj.put("catid", rs.getString("CatId"));
			jobj.put("subcatid", rs.getString("SubCatId"));
			jobj.put("productid", rs.getString("ProductId"));
			jobj.put("rate", rs.getString("Rate"));
			jobj.put("pic", rs.getString("Picture"));
			jobj.put("des",rs.getString("Description"));
			jobj.put("stock",rs.getString("Stock"));
			//System.out.println(rs.getString("ProductId"));
			//System.out.println(rs.getString("ProductName"));
			//System.out.println(rs.getString("Rate"));
			//System.out.println(rs.getString("CatId"));
			//System.out.println(rs.getString("SubCatId"));
			//System.out.println(rs.getString("Description"));
			//System.out.println(rs.getString("Picture"));
			//System.out.println(rs.getString("Stock"));
			jarr.put(jobj);
		}
		PrintWriter pr=response.getWriter();
		System.out.println(jarr);
		pr.print(jarr);
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (JSONException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	}

}

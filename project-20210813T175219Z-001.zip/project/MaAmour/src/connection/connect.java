package connection;
import java.sql.*;
public class connect
{
	static Connection conn=null;

	public static Connection getConnection()
	{
		
		try
		{
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			System.out.println("Driver Loaded");
		 conn=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;"+"databaseName=signup;user=myadmin;password=testadmin");
			System.out.println("connection Created");
		} 
		catch (ClassNotFoundException E) {
			// TODO Auto-generated catch block
			E.printStackTrace();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}	
		return conn;
	}
}
